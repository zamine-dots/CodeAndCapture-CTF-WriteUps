OPERATION LOCKBOX
=================
CLASSIFICATION: TOP SECRET
HANDLER: AGENT ZERO
NOTE: If you are reading this, you already know too much.
